### Task 2: Storage Layer

**Files:**
- Create: `src/storage/providers.js`
- Create: `src/storage/prompts.js`
- Create: `src/storage/settings.js`

**Purpose:** Thin wrappers around `chrome.storage.sync` for CRUD operations on providers, prompts, and settings.

- [ ] **Step 1: Create providers storage**

```js
// src/storage/providers.js
const STORAGE_KEY = 'providers'

export async function getProviders() {
  const result = await chrome.storage.sync.get(STORAGE_KEY)
  return result[STORAGE_KEY] || []
}

export async function saveProviders(providers) {
  await chrome.storage.sync.set({ [STORAGE_KEY]: providers })
}

export async function addProvider(provider) {
  const providers = await getProviders()
  provider.id = crypto.randomUUID()
  providers.push(provider)
  await saveProviders(providers)
  return provider
}

export async function updateProvider(id, updates) {
  const providers = await getProviders()
  const index = providers.findIndex(p => p.id === id)
  if (index === -1) throw new Error('Provider not found')
  providers[index] = { ...providers[index], ...updates }
  await saveProviders(providers)
  return providers[index]
}

export async function deleteProvider(id) {
  const providers = await getProviders()
  await saveProviders(providers.filter(p => p.id !== id))
}

export async function getDefaultProvider() {
  const providers = await getProviders()
  return providers.find(p => p.isDefault) || providers[0] || null
}
```

- [ ] **Step 2: Create prompts storage**

```js
// src/storage/prompts.js
const STORAGE_KEY = 'prompts'

const DEFAULT_PROMPTS = [
  {
    id: 'default-translate-en',
    name: 'Translate to English',
    template: 'Translate the following text to English:\n\n{text}',
    showInContextMenu: true,
  },
  {
    id: 'default-translate-native',
    name: 'Translate to Native',
    template: 'Translate to {language}:\n\n{text}',
    showInContextMenu: true,
  },
  {
    id: 'default-correct-grammar',
    name: 'Correct Grammar',
    template: 'Correct the grammar and fix typos:\n\n{text}',
    showInContextMenu: true,
  },
  {
    id: 'default-professional-tone',
    name: 'Professional Tone',
    template: 'Rewrite in a professional tone:\n\n{text}',
    showInContextMenu: true,
  },
  {
    id: 'default-simplify',
    name: 'Simplify',
    template: 'Rewrite this in simpler English:\n\n{text}',
    showInContextMenu: true,
  },
]

export async function getPrompts() {
  const result = await chrome.storage.sync.get(STORAGE_KEY)
  return result[STORAGE_KEY] || null
}

export async function initializePrompts() {
  let prompts = await getPrompts()
  if (!prompts) {
    await savePrompts(DEFAULT_PROMPTS)
    return DEFAULT_PROMPTS
  }
  return prompts
}

export async function savePrompts(prompts) {
  await chrome.storage.sync.set({ [STORAGE_KEY]: prompts })
}

export async function addPrompt(prompt) {
  const prompts = await getPrompts() || []
  prompt.id = crypto.randomUUID()
  prompts.push(prompt)
  await savePrompts(prompts)
  return prompt
}

export async function updatePrompt(id, updates) {
  const prompts = await getPrompts() || []
  const index = prompts.findIndex(p => p.id === id)
  if (index === -1) throw new Error('Prompt not found')
  prompts[index] = { ...prompts[index], ...updates }
  await savePrompts(prompts)
  return prompts[index]
}

export async function deletePrompt(id) {
  const prompts = await getPrompts() || []
  await savePrompts(prompts.filter(p => p.id !== id))
}
```

- [ ] **Step 3: Create settings storage**

```js
// src/storage/settings.js
const STORAGE_KEY = 'settings'

export async function getSettings() {
  const result = await chrome.storage.sync.get(STORAGE_KEY)
  return result[STORAGE_KEY] || {
    nativeLanguage: null,
    defaultProviderId: null,
  }
}

export async function saveSettings(settings) {
  await chrome.storage.sync.set({ [STORAGE_KEY]: settings })
}

export async function updateSettings(updates) {
  const settings = await getSettings()
  const updated = { ...settings, ...updates }
  await saveSettings(updated)
  return updated
}
```

---

