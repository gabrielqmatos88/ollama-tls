## Task 3: Template Parser Utility — Complete

### What was done
Created `src/utils/templateParser.js` with two exported functions:

- **`parseVariables(template)`** — Parses `{name:type}` syntax from template strings. Returns array of `{ name, type, options }` objects. Supports types: `text` (default), `number`, `textarea`, `boolean`, `select` (semicolon-separated), `radio` (pipe-separated). Skips `{text}` as it's reserved for selected text.

- **`replaceVariables(template, selectedText, variableValues)`** — Replaces all `{name}` and `{name:type}` placeholders with user-provided values. `{text}` and `{text:*}` are replaced with `selectedText`. Undefined/null values leave the placeholder intact.

### Verification
- `npm run build` passed successfully (107ms, no errors)
- File exports match spec exactly

### Commit
- `17589bc` feat: add template parser utility for {name:type} variable syntax
