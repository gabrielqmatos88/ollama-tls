# Task 5: Background Service Worker - Report

## Status: DONE

## Commit
- `2312d7c` - feat: add background service worker for context menus and message routing

## Implementation Summary

Created `src/background/main.js` with:
- `onInstalled` listener that initializes default prompts and rebuilds context menus
- Storage change listener that auto-rebuilds menus when prompts update
- `rebuildContextMenus()` that creates parent menu + child items per prompt with `showInContextMenu: true`
- Context menu click handler that opens side panel and sends `PROMPT_SELECTED` message
- Message listener for `OPEN_SIDEBAR_WITH_PROMPT` from content script, forwarding to side panel

Updated `manifest.config.js` to register the service worker:
```js
background: {
  service_worker: 'src/background/main.js',
  type: 'module',
}
```

## Verification
- Build passes (`npm run build`)
- Generated manifest includes background service worker configuration
- Service worker loader correctly imports the bundled module
