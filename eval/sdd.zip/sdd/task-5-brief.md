### Task 5: Background Service Worker

**Files:**
- Modify: `src/background/main.js` (create new, replacing any existing)

**Purpose:** Register context menus, route messages between content script and side panel.

- [ ] **Step 1: Create background service worker**

```js
// src/background/main.js
import { getPrompts, initializePrompts } from '@/storage/prompts'
import { getSettings } from '@/storage/settings'

// Initialize on install
chrome.runtime.onInstalled.addListener(async () => {
  await initializePrompts()
  await rebuildContextMenus()
})

// Rebuild context menus when prompts change
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'sync' && changes.prompts) {
    rebuildContextMenus()
  }
})

async function rebuildContextMenus() {
  // Remove all existing menu items
  await chrome.contextMenus.removeAll()

  const prompts = await getPrompts()
  const contextPrompts = prompts.filter(p => p.showInContextMenu)

  // Parent menu
  chrome.contextMenus.create({
    id: 'ollama-tls',
    title: 'ollama-tls',
    contexts: ['selection'],
  })

  // One entry per prompt
  for (const prompt of contextPrompts) {
    chrome.contextMenus.create({
      id: `prompt:${prompt.id}`,
      parentId: 'ollama-tls',
      title: prompt.name,
      contexts: ['selection'],
    })
  }
}

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!info.menuItemId.startsWith('prompt:')) return

  const promptId = info.menuItemId.replace('prompt:', '')
  const selectedText = info.selectionText

  // Open side panel and send data
  await chrome.sidePanel.open({ tabId: tab.id })
  await chrome.sidePanel.setOptions({
    tabId: tab.id,
    enabled: true,
  })

  // Small delay to let side panel initialize
  setTimeout(() => {
    chrome.runtime.sendMessage({
      type: 'PROMPT_SELECTED',
      promptId,
      selectedText,
      variables: {},
    }).catch(() => {})
  }, 300)
})

// Handle messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'OPEN_SIDEBAR_WITH_PROMPT') {
    const { promptId, selectedText, variables } = message

    // Open side panel for the tab that sent the message
    chrome.sidePanel.open({ tabId: sender.tab.id })
    chrome.sidePanel.setOptions({
      tabId: sender.tab.id,
      enabled: true,
    })

    // Forward to side panel
    setTimeout(() => {
      chrome.runtime.sendMessage({
        type: 'PROMPT_SELECTED',
        promptId,
        selectedText,
        variables,
      }).catch(() => {})
    }, 300)

    sendResponse({ ok: true })
  }
  return true // keep message channel open for async response
})
```

---

