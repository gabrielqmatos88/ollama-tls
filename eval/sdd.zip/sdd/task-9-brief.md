### Task 9: Content Script — Prompt Popup

**Files:**
- Modify: `src/content/main.jsx`
- Create: `src/content/PromptPopup.jsx`
- Create: `src/content/popup.css`

**Purpose:** Detect text selection, show floating popup with prompts and typed variable inputs.

- [ ] **Step 1: Create popup.css**

```css
/* src/content/popup.css */
.crjsx-prompt-popup {
  position: absolute;
  z-index: 2147483647;
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  padding: 8px;
  min-width: 200px;
  max-width: 320px;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  font-size: 14px;
  color: #333;
}

.crjsx-prompt-popup .prompt-list {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.crjsx-prompt-popup .prompt-item {
  padding: 8px 12px;
  border: none;
  background: none;
  cursor: pointer;
  text-align: left;
  border-radius: 6px;
  font-size: 14px;
  color: #333;
}

.crjsx-prompt-popup .prompt-item:hover {
  background: #f3f4f6;
}

.crjsx-prompt-popup .variables-form {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 8px 0;
}

.crjsx-prompt-popup .variables-form label {
  display: flex;
  flex-direction: column;
  gap: 4px;
  font-size: 13px;
  color: #555;
}

.crjsx-prompt-popup .variables-form input,
.crjsx-prompt-popup .variables-form textarea,
.crjsx-prompt-popup .variables-form select {
  padding: 6px 8px;
  border: 1px solid #d1d5db;
  border-radius: 4px;
  font-size: 13px;
}

.crjsx-prompt-popup .variables-form .radio-group {
  display: flex;
  gap: 12px;
}

.crjsx-prompt-popup .variables-form .radio-group label {
  flex-direction: row;
  align-items: center;
  gap: 4px;
}

.crjsx-prompt-popup .variables-form .checkbox-label {
  flex-direction: row;
  align-items: center;
  gap: 6px;
}

.crjsx-prompt-popup .form-actions {
  display: flex;
  gap: 8px;
  padding-top: 4px;
}

.crjsx-prompt-popup .btn-confirm {
  padding: 6px 14px;
  border: none;
  border-radius: 4px;
  background: #2563eb;
  color: white;
  cursor: pointer;
  font-size: 13px;
}

.crjsx-prompt-popup .btn-confirm:hover {
  background: #1d4ed8;
}

.crjsx-prompt-popup .btn-cancel {
  padding: 6px 14px;
  border: 1px solid #d1d5db;
  border-radius: 4px;
  background: white;
  cursor: pointer;
  font-size: 13px;
  color: #555;
}
```

- [ ] **Step 2: Create PromptPopup.jsx**

```jsx
// src/content/PromptPopup.jsx
import { useState, useEffect, useRef } from 'react'
import { getPrompts } from '@/storage/prompts'
import { getSettings } from '@/storage/settings'
import { parseVariables } from '@/utils/templateParser'

export default function PromptPopup({ selectedText, position, onSend, onClose }) {
  const [prompts, setPrompts] = useState([])
  const [selectedPrompt, setSelectedPrompt] = useState(null)
  const [variableValues, setVariableValues] = useState({})
  const [settings, setSettings] = useState({})
  const popupRef = useRef(null)

  useEffect(() => {
    async function load() {
      const allPrompts = await getPrompts()
      setPrompts(allPrompts.filter(p => p.showInContextMenu))
      const s = await getSettings()
      setSettings(s)
    }
    load()
  }, [])

  useEffect(() => {
    function handleClickOutside(e) {
      if (popupRef.current && !popupRef.current.contains(e.target)) {
        onClose()
      }
    }
    function handleEscape(e) {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('mousedown', handleClickOutside)
    document.addEventListener('keydown', handleEscape)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
      document.removeEventListener('keydown', handleEscape)
    }
  }, [onClose])

  function handlePromptClick(prompt) {
    const variables = parseVariables(prompt.template)
    if (variables.length === 0) {
      // No variables to fill, send immediately
      onSend(prompt.id, selectedText, {})
      return
    }
    // Pre-fill language variable with native language if available
    const defaults = {}
    if (settings.nativeLanguage) {
      const langVar = variables.find(v => v.name === 'language')
      if (langVar) defaults.language = settings.nativeLanguage
    }
    setVariableValues(defaults)
    setSelectedPrompt(prompt)
  }

  function handleConfirm() {
    onSend(selectedPrompt.id, selectedText, variableValues)
  }

  const variables = selectedPrompt ? parseVariables(selectedPrompt.template) : []

  return (
    <div className="crjsx-prompt-popup" ref={popupRef} style={{ top: position.top, left: position.left }}>
      {!selectedPrompt ? (
        <div className="prompt-list">
          {prompts.map(prompt => (
            <button key={prompt.id} className="prompt-item" onClick={() => handlePromptClick(prompt)}>
              {prompt.name}
            </button>
          ))}
        </div>
      ) : (
        <div>
          <div style={{ fontWeight: 600, marginBottom: 8 }}>{selectedPrompt.name}</div>
          <div className="variables-form">
            {variables.map(variable => (
              <label key={variable.name}>
                {variable.name}
                {variable.type === 'text' && (
                  <input
                    type="text"
                    value={variableValues[variable.name] || ''}
                    onChange={e => setVariableValues({ ...variableValues, [variable.name]: e.target.value })}
                  />
                )}
                {variable.type === 'number' && (
                  <input
                    type="number"
                    value={variableValues[variable.name] || ''}
                    onChange={e => setVariableValues({ ...variableValues, [variable.name]: e.target.value })}
                  />
                )}
                {variable.type === 'textarea' && (
                  <textarea
                    value={variableValues[variable.name] || ''}
                    onChange={e => setVariableValues({ ...variableValues, [variable.name]: e.target.value })}
                    rows={3}
                  />
                )}
                {variable.type === 'boolean' && (
                  <div className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={variableValues[variable.name] || false}
                      onChange={e => setVariableValues({ ...variableValues, [variable.name]: e.target.checked })}
                      style={{ width: 'auto' }}
                    />
                    <span>{variable.name}</span>
                  </div>
                )}
                {variable.type === 'select' && (
                  <select
                    value={variableValues[variable.name] || ''}
                    onChange={e => setVariableValues({ ...variableValues, [variable.name]: e.target.value })}
                  >
                    <option value="">Select...</option>
                    {variable.options.map(opt => (
                      <option key={opt} value={opt}>{opt}</option>
                    ))}
                  </select>
                )}
                {variable.type === 'radio' && (
                  <div className="radio-group">
                    {variable.options.map(opt => (
                      <label key={opt}>
                        <input
                          type="radio"
                          name={variable.name}
                          value={opt}
                          checked={variableValues[variable.name] === opt}
                          onChange={e => setVariableValues({ ...variableValues, [variable.name]: e.target.value })}
                          style={{ width: 'auto' }}
                        />
                        {opt}
                      </label>
                    ))}
                  </div>
                )}
              </label>
            ))}
          </div>
          <div className="form-actions">
            <button className="btn-confirm" onClick={handleConfirm}>Send</button>
            <button className="btn-cancel" onClick={() => setSelectedPrompt(null)}>Back</button>
          </div>
        </div>
      )}
    </div>
  )
}
```

- [ ] **Step 3: Update content main.jsx**

```jsx
// src/content/main.jsx
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import PromptPopup from './PromptPopup.jsx'
import './popup.css'

let popupContainer = null
let popupRoot = null

function showPopup(selectedText, rect) {
  // Remove existing popup if any
  hidePopup()

  popupContainer = document.createElement('div')
  popupContainer.id = 'crjsx-prompt-popup-root'
  popupContainer.style.position = 'absolute'
  popupContainer.style.zIndex = '2147483647'
  document.body.appendChild(popupContainer)

  // Position below the selection
  const scrollX = window.scrollX
  const scrollY = window.scrollY
  const top = scrollY + rect.bottom + 8
  const left = scrollX + rect.left

  popupRoot = createRoot(popupContainer)
  popupRoot.render(
    <StrictMode>
      <PromptPopup
        selectedText={selectedText}
        position={{ top, left }}
        onSend={handleSend}
        onClose={hidePopup}
      />
    </StrictMode>,
  )
}

function hidePopup() {
  if (popupRoot) {
    popupRoot.unmount()
    popupRoot = null
  }
  if (popupContainer) {
    popupContainer.remove()
    popupContainer = null
  }
}

function handleSend(promptId, selectedText, variables) {
  chrome.runtime.sendMessage({
    type: 'OPEN_SIDEBAR_WITH_PROMPT',
    promptId,
    selectedText,
    variables,
  })
  hidePopup()
}

// Listen for text selection
document.addEventListener('mouseup', (e) => {
  // Ignore clicks on our own popup
  if (e.target.closest('#crjsx-prompt-popup-root')) return

  const selection = window.getSelection()
  const selectedText = selection.toString().trim()

  if (!selectedText) return

  const range = selection.getRangeAt(0)
  const rect = range.getBoundingClientRect()

  showPopup(selectedText, rect)
})
```

---

