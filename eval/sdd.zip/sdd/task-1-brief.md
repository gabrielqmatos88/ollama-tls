### Task 1: Update Manifest Configuration

**Files:**
- Modify: `manifest.config.js`

**Purpose:** Add required permissions and options page to the manifest.

- [ ] **Step 1: Update manifest.config.js**

```js
import { defineManifest } from '@crxjs/vite-plugin'
import pkg from './package.json'

export default defineManifest({
  manifest_version: 3,
  name: pkg.name,
  version: pkg.version,
  icons: {
    48: 'public/logo.png',
  },
  permissions: [
    'sidePanel',
    'contentSettings',
    'contextMenus',
    'storage',
  ],
  host_permissions: [
    '<all_urls>',
  ],
  action: {
    default_icon: {
      48: 'public/logo.png',
    },
    default_popup: 'src/popup/index.html',
  },
  content_scripts: [{
    js: ['src/content/main.jsx'],
    matches: ['https://*/*'],
  }],
  side_panel: {
    default_path: 'src/sidepanel/index.html',
  },
  options_page: 'src/options/index.html',
})
```

- [ ] **Step 2: Verify build still works**

Run: `npm run build`
Expected: Build succeeds with no errors.

---

