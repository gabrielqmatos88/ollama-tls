### Task 10: Side Panel — Chat Interface

**Files:**
- Modify: `src/sidepanel/App.jsx`
- Create: `src/sidepanel/ChatMessage.jsx`
- Create: `src/sidepanel/ChatInput.jsx`
- Modify: `src/sidepanel/App.css`

**Purpose:** Chat interface with streaming responses and conversation persistence.

- [ ] **Step 1: Create ChatMessage.jsx**

```jsx
// src/sidepanel/ChatMessage.jsx
export default function ChatMessage({ message, onCopy }) {
  const isUser = message.role === 'user'

  return (
    <div className={`chat-message ${isUser ? 'user' : 'assistant'}`}>
      <div className="message-content">
        <pre style={{ whiteSpace: 'pre-wrap', fontFamily: 'inherit', margin: 0 }}>{message.content}</pre>
      </div>
      {!isUser && (
        <button className="copy-btn" onClick={() => onCopy(message.content)} title="Copy">
          Copy
        </button>
      )}
    </div>
  )
}
```

- [ ] **Step 2: Create ChatInput.jsx**

```jsx
// src/sidepanel/ChatInput.jsx
import { useState, useRef, useEffect } from 'react'

export default function ChatInput({ onSend, disabled }) {
  const [text, setText] = useState('')
  const textareaRef = useRef(null)

  useEffect(() => {
    textareaRef.current?.focus()
  }, [])

  function handleKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  function handleSend() {
    const trimmed = text.trim()
    if (!trimmed || disabled) return
    onSend(trimmed)
    setText('')
  }

  return (
    <div className="chat-input">
      <textarea
        ref={textareaRef}
        value={text}
        onChange={e => setText(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Type a message... (Enter to send, Shift+Enter for newline)"
        disabled={disabled}
        rows={2}
      />
      <button onClick={handleSend} disabled={disabled || !text.trim()}>
        Send
      </button>
    </div>
  )
}
```

- [ ] **Step 3: Update sidepanel App.css**

```css
/* src/sidepanel/App.css */
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f9fafb;
  color: #333;
  height: 100vh;
  display: flex;
  flex-direction: column;
}

#root {
  flex: 1;
  display: flex;
  flex-direction: column;
  height: 100vh;
}

.chat-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background: white;
  border-bottom: 1px solid #e5e7eb;
}

.chat-header h2 {
  font-size: 16px;
}

.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.chat-message {
  max-width: 90%;
  padding: 10px 14px;
  border-radius: 12px;
  font-size: 14px;
  line-height: 1.5;
}

.chat-message.user {
  align-self: flex-end;
  background: #2563eb;
  color: white;
  border-bottom-right-radius: 4px;
}

.chat-message.assistant {
  align-self: flex-start;
  background: white;
  border: 1px solid #e5e7eb;
  border-bottom-left-radius: 4px;
}

.copy-btn {
  margin-top: 8px;
  padding: 4px 10px;
  border: 1px solid #d1d5db;
  border-radius: 4px;
  background: white;
  cursor: pointer;
  font-size: 12px;
  color: #555;
}

.copy-btn:hover {
  background: #f3f4f6;
}

.chat-input {
  display: flex;
  gap: 8px;
  padding: 12px 16px;
  background: white;
  border-top: 1px solid #e5e7eb;
}

.chat-input textarea {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  font-size: 14px;
  resize: none;
  font-family: inherit;
}

.chat-input textarea:focus {
  outline: none;
  border-color: #2563eb;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.2);
}

.chat-input button {
  padding: 8px 16px;
  border: none;
  border-radius: 8px;
  background: #2563eb;
  color: white;
  cursor: pointer;
  font-size: 14px;
  align-self: flex-end;
}

.chat-input button:hover {
  background: #1d4ed8;
}

.chat-input button:disabled {
  background: #93c5fd;
  cursor: not-allowed;
}

.stop-btn {
  padding: 4px 12px;
  border: 1px solid #dc2626;
  border-radius: 4px;
  background: white;
  color: #dc2626;
  cursor: pointer;
  font-size: 13px;
}

.stop-btn:hover {
  background: #fef2f2;
}

.empty-state {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #9ca3af;
  font-size: 14px;
}

.streaming-indicator {
  display: inline-block;
  width: 8px;
  height: 8px;
  background: #2563eb;
  border-radius: 50%;
  animation: pulse 1s infinite;
  margin-left: 4px;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.3; }
}
```

- [ ] **Step 4: Update sidepanel App.jsx**

```jsx
// src/sidepanel/App.jsx
import { useState, useEffect, useRef } from 'react'
import ChatMessage from './ChatMessage.jsx'
import ChatInput from './ChatInput.jsx'
import { getPrompts } from '@/storage/prompts'
import { getDefaultProvider } from '@/storage/providers'
import { replaceVariables } from '@/utils/templateParser'
import { callProvider } from '@/api/client.js'
import './App.css'

const CONVERSATIONS_KEY = 'conversations'

async function loadConversation() {
  const result = await chrome.storage.local.get(CONVERSATIONS_KEY)
  const conversations = result[CONVERSATIONS_KEY] || []
  return conversations[0] || { id: crypto.randomUUID(), messages: [], createdAt: Date.now(), updatedAt: Date.now() }
}

async function saveConversation(conversation) {
  conversation.updatedAt = Date.now()
  await chrome.storage.local.set({ [CONVERSATIONS_KEY]: [conversation] })
}

export default function App() {
  const [conversation, setConversation] = useState(null)
  const [isStreaming, setIsStreaming] = useState(false)
  const [streamingContent, setStreamingContent] = useState('')
  const abortRef = useRef(null)
  const messagesEndRef = useRef(null)

  useEffect(() => {
    loadConversation().then(setConversation)
  }, [])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [conversation?.messages, streamingContent])

  // Listen for prompt from content script / background
  useEffect(() => {
    function handleMessage(message) {
      if (message.type === 'PROMPT_SELECTED') {
        handlePromptReceived(message.promptId, message.selectedText, message.variables)
      }
    }
    chrome.runtime.onMessage.addListener(handleMessage)
    return () => chrome.runtime.onMessage.removeListener(handleMessage)
  }, [conversation])

  async function handlePromptReceived(promptId, selectedText, variables) {
    const prompts = await getPrompts()
    const prompt = prompts.find(p => p.id === promptId)
    if (!prompt) return

    const content = replaceVariables(prompt.template, selectedText, variables)

    const newMessage = { role: 'user', content }
    const updated = {
      ...conversation,
      messages: [...(conversation?.messages || []), newMessage],
    }
    setConversation(updated)
    await saveConversation(updated)

    await sendToAI(updated.messages)
  }

  async function sendToAI(messages) {
    const provider = await getDefaultProvider()
    if (!provider) {
      const errorMsg = { role: 'assistant', content: 'Error: No provider configured. Please add a provider in the options page.' }
      const updated = { ...conversation, messages: [...messages, errorMsg] }
      setConversation(updated)
      await saveConversation(updated)
      return
    }

    setIsStreaming(true)
    setStreamingContent('')
    abortRef.current = new AbortController()

    try {
      const aiMessages = messages.map(m => ({ role: m.role, content: m.content }))

      await callProvider({
        baseUrl: provider.baseUrl,
        apiKey: provider.apiKey,
        model: provider.model,
        messages: aiMessages,
        signal: abortRef.current.signal,
        onChunk: (delta, full) => setStreamingContent(full),
      })
    } catch (err) {
      if (err.name === 'AbortError') {
        // User stopped generation
      } else {
        setStreamingContent(`Error: ${err.message}`)
      }
    } finally {
      setIsStreaming(false)
      const finalContent = streamingContent || ''
      if (finalContent) {
        const assistantMsg = { role: 'assistant', content: finalContent }
        const updated = { ...conversation, messages: [...messages, assistantMsg] }
        setConversation(updated)
        await saveConversation(updated)
      }
      setStreamingContent('')
      abortRef.current = null
    }
  }

  async function handleSend(text) {
    const newMessage = { role: 'user', content: text }
    const updated = {
      ...conversation,
      messages: [...(conversation?.messages || []), newMessage],
    }
    setConversation(updated)
    await saveConversation(updated)
    await sendToAI(updated.messages)
  }

  function handleStop() {
    abortRef.current?.abort()
  }

  function handleCopy(text) {
    navigator.clipboard.writeText(text)
  }

  async function handleNewConversation() {
    const newConv = { id: crypto.randomUUID(), messages: [], createdAt: Date.now(), updatedAt: Date.now() }
    setConversation(newConv)
    await saveConversation(newConv)
  }

  const messages = conversation?.messages || []

  return (
    <>
      <div className="chat-header">
        <h2>ollama-tls</h2>
        <div style={{ display: 'flex', gap: 8 }}>
          {isStreaming && <button className="stop-btn" onClick={handleStop}>Stop</button>}
          <button className="btn btn-secondary" onClick={handleNewConversation} style={{ padding: '4px 12px', fontSize: 13 }}>New</button>
        </div>
      </div>
      <div className="chat-messages">
        {messages.length === 0 && !isStreaming && (
          <div className="empty-state">Select text on a page and choose a prompt to get started.</div>
        )}
        {messages.map((msg, i) => (
          <ChatMessage key={i} message={msg} onCopy={handleCopy} />
        ))}
        {isStreaming && streamingContent && (
          <div className="chat-message assistant">
            <div className="message-content">
              <pre style={{ whiteSpace: 'pre-wrap', fontFamily: 'inherit', margin: 0 }}>{streamingContent}</pre>
            </div>
            <span className="streaming-indicator" />
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <ChatInput onSend={handleSend} disabled={isStreaming} />
    </>
  )
}
```

---

