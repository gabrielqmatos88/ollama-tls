### Task 11: Update Popup Entry Point

**Files:**
- Modify: `src/popup/App.jsx`
- Modify: `src/popup/App.css`

**Purpose:** Replace the default template popup with a minimal launcher that opens the side panel.

- [ ] **Step 1: Update popup App.jsx**

```jsx
// src/popup/App.jsx
import './App.css'

export default function App() {
  function handleOpenSidePanel() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.sidePanel.open({ tabId: tabs[0].id })
      }
    })
    window.close()
  }

  function handleOpenOptions() {
    chrome.runtime.openOptionsPage()
    window.close()
  }

  return (
    <div className="popup-container">
      <h2>ollama-tls</h2>
      <p className="popup-desc">AI text transformation</p>
      <div className="popup-actions">
        <button className="btn btn-primary" onClick={handleOpenSidePanel}>Open Chat</button>
        <button className="btn btn-secondary" onClick={handleOpenOptions}>Settings</button>
      </div>
    </div>
  )
}
```

- [ ] **Step 2: Update popup App.css**

```css
/* src/popup/App.css */
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  width: 220px;
  padding: 16px;
}

.popup-container {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.popup-container h2 {
  font-size: 16px;
}

.popup-desc {
  font-size: 13px;
  color: #666;
}

.popup-actions {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.btn {
  padding: 8px 16px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
}

.btn-primary {
  background: #2563eb;
  color: white;
}

.btn-primary:hover {
  background: #1d4ed8;
}

.btn-secondary {
  background: #e5e7eb;
  color: #333;
}

.btn-secondary:hover {
  background: #d1d5db;
}
```

---

