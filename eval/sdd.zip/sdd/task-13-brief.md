### Task 13: Build & Verify

**Purpose:** Ensure the extension builds and loads correctly in Chrome.

- [ ] **Step 1: Run the build**

Run: `npm run build`
Expected: Build succeeds with no errors. Check that `dist/` contains:
- `manifest.json`
- `options/index.html`
- `sidepanel/index.html`
- `popup/index.html`
- Content script files
- Background service worker

- [ ] **Step 2: Load in Chrome for testing**

1. Open Chrome → `chrome://extensions/`
2. Enable "Developer mode"
3. Click "Load unpacked" → select the `dist/` folder
4. Verify the extension icon appears in the toolbar

- [ ] **Step 3: Test the full flow**

1. Click extension icon → popup shows "Open Chat" and "Settings"
2. Click "Settings" → options page opens with three tabs
3. Add a provider (e.g., Ollama at `http://localhost:11434/v1`, model `llama3.2`)
4. Test connection → should show success
5. Go to any HTTPS page, select text → floating popup with prompts appears
6. Click a prompt → side panel opens with the prompt sent to AI
7. Verify streaming response appears in side panel
8. Type a follow-up message → AI responds with conversation context
9. Close and reopen side panel → history persists
10. Right-click selected text → context menu shows prompts
