### Task 12: Update Vite Config for Options Page

**Files:**
- Modify: `vite.config.js`

**Purpose:** Ensure Vite builds the options page entry correctly.

- [ ] **Step 1: Update vite.config.js**

The CRXJS plugin should automatically pick up the options page from the manifest. No changes needed to `vite.config.js` — the `options_page` field in `manifest.config.js` is sufficient.

Verify by running `npm run build` and checking that `dist/options/index.html` exists.

---

