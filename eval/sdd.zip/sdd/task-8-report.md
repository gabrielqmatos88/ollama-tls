## Task 8: Options Page — Settings Tab

**Status:** DONE

### Implementation Summary

Replaced the SettingsTab stub (`src/options/SettingsTab.jsx`) with full implementation:

- **Native Language setting**: Input field for configuring the user's native language, used for "Translate to Native" prompt. Displays browser language as placeholder/default.
- **Save Settings**: Calls `updateSettings()` from `@/storage/settings` to persist `nativeLanguage` to `chrome.storage.sync`. Shows "Saved!" confirmation for 2 seconds.
- **Clear Conversation History**: Calls `chrome.storage.local.remove('conversations')` to delete all saved conversations from the side panel.

### Files Modified
- `src/options/SettingsTab.jsx` — Replaced 8-line stub with 67-line full implementation

### Build Verification
- `npm run build` passed successfully (45 modules transformed)

### Commit
- `e39e8d9` — feat: implement options page SettingsTab with native language and clear history
