## Task 1: Update Manifest Configuration — Report

### What was done

Updated `manifest.config.js` to add:
- `contextMenus` and `storage` to `permissions`
- `host_permissions: ['<all_urls>']`
- `options_page: 'src/options/index.html'`

Created minimal options page entrypoint (`src/options/`) with `index.html`, `main.jsx`, and `App.jsx` — required because the manifest references it and the build would fail without the file present.

### Verification

- `npm run build` succeeds with no errors
- Generated `dist/manifest.json` contains all four permissions, host_permissions, and options_page

### Commit

- `d7d8e58` — feat: add contextMenus, storage permissions and options page to manifest
